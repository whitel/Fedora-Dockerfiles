#!/bin/sh
zip git_sprites.zip \
addition.png \
apply-patch.png \
branch.png \
branch.png \
checkout.png \
cherry-pick.png \
compare.png \
open.png \
conflict-file.gif \
fetch.png \
file.png \
incoming-commit.png \
merge-squash.png \
merge.png \
notsure.gif \
open.png \
outgoing-commit.png \
pull.png \
rebase.png \
remote.png \
removal.png \
repository.png \
reset.png \
stage.png \
tag.png \
unstage.png
